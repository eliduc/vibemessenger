/**
 * VibeMessenger Key Verification - Crypto Module
 * Генерация Safety Number и Emoji Fingerprint
 */

const VibeCryptoVerification = (function() {
    'use strict';

    // 64 различимых эмодзи для fingerprint (6 из них = 36 бит энтропии)
    const EMOJI_SET = [
        // Животные (16)
        '🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼',
        '🐨', '🐯', '🦁', '🐮', '🐷', '🐸', '🐵', '🦄',
        // Цветы и природа (8)
        '🌸', '🌺', '🌻', '🌹', '🌴', '🌵', '🍀', '🌈',
        // Фрукты (8)
        '🍎', '🍊', '🍋', '🍇', '🍓', '🍒', '🥝', '🍑',
        // Космос и погода (8)
        '⭐', '🌙', '☀️', '🔥', '❄️', '💧', '🌊', '⚡',
        // Музыка и игры (8)
        '🎸', '🎹', '🎺', '🥁', '🎯', '🎱', '🎲', '🎪',
        // Транспорт (8)
        '🚀', '✈️', '🚁', '⛵', '🚂', '🚗', '🏍️', '🚲',
        // Предметы (8)
        '💎', '👑', '🎭', '🎨', '🔮', '🔐', '⚔️', '🛡️'
    ];

    /**
     * Генерирует Safety Number из двух identity keys
     * @param {string} myIdentityKeyBase64 - Мой identity key (base64)
     * @param {string} theirIdentityKeyBase64 - Identity key собеседника (base64)
     * @param {string} myUserId - Мой user ID
     * @param {string} theirUserId - User ID собеседника
     * @returns {Promise<string>} - 60-значный Safety Number
     */
    async function generateSafetyNumber(myIdentityKeyBase64, theirIdentityKeyBase64, myUserId, theirUserId) {
        try {
            // Декодируем ключи из base64
            const myKey = base64ToArrayBuffer(myIdentityKeyBase64);
            const theirKey = base64ToArrayBuffer(theirIdentityKeyBase64);

            // Сортируем для симметричности (оба видят одинаковый номер)
            let sortedKeys, sortedIds;
            
            if (myUserId < theirUserId) {
                sortedKeys = concatenateArrayBuffers(myKey, theirKey);
                sortedIds = myUserId + theirUserId;
            } else {
                sortedKeys = concatenateArrayBuffers(theirKey, myKey);
                sortedIds = theirUserId + myUserId;
            }

            // Добавляем user IDs к данным
            const idsBuffer = new TextEncoder().encode(sortedIds);
            const dataToHash = concatenateArrayBuffers(sortedKeys, idsBuffer);

            // SHA-256 хэш
            const hashBuffer = await crypto.subtle.digest('SHA-256', dataToHash);
            const hashArray = new Uint8Array(hashBuffer);

            // Конвертируем в 60 цифр (12 групп по 5 цифр)
            let safetyNumber = '';
            for (let i = 0; i < 30; i++) {
                // Берём по 2 байта и конвертируем в число 00000-99999
                const value = (hashArray[i % hashArray.length] * 256 + hashArray[(i + 1) % hashArray.length]) % 100000;
                safetyNumber += value.toString().padStart(5, '0');
                if (safetyNumber.length >= 60) break;
            }

            return safetyNumber.substring(0, 60);
        } catch (error) {
            console.error('Error generating safety number:', error);
            throw error;
        }
    }

    /**
     * Генерирует эмодзи fingerprint из Safety Number
     * @param {string} safetyNumber - 60-значный Safety Number
     * @returns {string[]} - Массив из 6 эмодзи
     */
    function generateEmojiFingerprint(safetyNumber) {
        const emojis = [];
        
        // Берём 6 секций по 10 цифр
        for (let i = 0; i < 6; i++) {
            const chunk = safetyNumber.substring(i * 10, (i + 1) * 10);
            const value = parseInt(chunk, 10);
            const index = value % EMOJI_SET.length;
            emojis.push(EMOJI_SET[index]);
        }
        
        return emojis;
    }

    /**
     * Форматирует Safety Number для отображения (12 блоков по 5 цифр)
     * @param {string} safetyNumber - 60-значный Safety Number
     * @returns {string} - Форматированная строка
     */
    function formatSafetyNumber(safetyNumber) {
        const blocks = [];
        for (let i = 0; i < 60; i += 5) {
            blocks.push(safetyNumber.substring(i, i + 5));
        }
        return blocks;
    }

    /**
     * Генерирует данные для QR-кода
     * @param {string} safetyNumber - Safety Number
     * @param {string} myUserId - Мой user ID
     * @param {string} theirUserId - User ID собеседника
     * @returns {string} - JSON строка для QR
     */
    function generateQRData(safetyNumber, myUserId, theirUserId) {
        return JSON.stringify({
            version: 1,
            safetyNumber: safetyNumber,
            users: [myUserId, theirUserId].sort()
        });
    }

    /**
     * Проверяет QR-код
     * @param {string} qrData - Данные из QR-кода
     * @param {string} expectedSafetyNumber - Ожидаемый Safety Number
     * @returns {boolean} - Совпадает ли
     */
    function verifyQRCode(qrData, expectedSafetyNumber) {
        try {
            const data = JSON.parse(qrData);
            return data.safetyNumber === expectedSafetyNumber;
        } catch (e) {
            return false;
        }
    }

    // === Вспомогательные функции ===

    function base64ToArrayBuffer(base64) {
        const binaryString = atob(base64);
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
        }
        return bytes.buffer;
    }

    function concatenateArrayBuffers(buffer1, buffer2) {
        const tmp = new Uint8Array(buffer1.byteLength + buffer2.byteLength);
        tmp.set(new Uint8Array(buffer1), 0);
        tmp.set(new Uint8Array(buffer2), buffer1.byteLength);
        return tmp.buffer;
    }

    // Локальное хранилище верификаций
    const VERIFIED_STORAGE_KEY = 'vibe_verified_keys';

    function saveVerificationStatus(myUserId, theirUserId, verified) {
        try {
            const storage = JSON.parse(localStorage.getItem(VERIFIED_STORAGE_KEY) || '{}');
            const key = [myUserId, theirUserId].sort().join('_');
            storage[key] = {
                verified: verified,
                timestamp: Date.now()
            };
            localStorage.setItem(VERIFIED_STORAGE_KEY, JSON.stringify(storage));
        } catch (e) {
            console.error('Error saving verification status:', e);
        }
    }

    function getVerificationStatus(myUserId, theirUserId) {
        try {
            const storage = JSON.parse(localStorage.getItem(VERIFIED_STORAGE_KEY) || '{}');
            const key = [myUserId, theirUserId].sort().join('_');
            return storage[key] || { verified: false, timestamp: null };
        } catch (e) {
            return { verified: false, timestamp: null };
        }
    }

    // Public API
    return {
        generateSafetyNumber,
        generateEmojiFingerprint,
        formatSafetyNumber,
        generateQRData,
        verifyQRCode,
        saveVerificationStatus,
        getVerificationStatus,
        EMOJI_SET
    };
})();

// Экспорт для глобального использования
if (typeof window !== 'undefined') {
    window.VibeCryptoVerification = VibeCryptoVerification;
}
