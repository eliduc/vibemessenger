/**
 * VibeMessenger Key Verification - UI Module
 * Интерфейс для верификации ключей шифрования
 */

const KeyVerificationUI = (function() {
    'use strict';

    let currentVerificationData = null;

    /**
     * Открывает модальное окно верификации ключей
     * @param {string} theirUserId - ID собеседника
     * @param {string} theirUsername - Имя собеседника
     */
    async function openKeyVerification(theirUserId, theirUsername) {
        try {
            // Получаем identity keys
            const myIdentityKey = await getMyIdentityKey();
            const theirIdentityKey = await getTheirIdentityKey(theirUserId);
            
            if (!myIdentityKey || !theirIdentityKey) {
                showToast('Не удалось получить ключи шифрования');
                return;
            }

            const myUserId = state.user.id;

            // Генерируем Safety Number
            const safetyNumber = await VibeCryptoVerification.generateSafetyNumber(
                myIdentityKey,
                theirIdentityKey,
                myUserId,
                theirUserId
            );

            // Генерируем эмодзи
            const emojis = VibeCryptoVerification.generateEmojiFingerprint(safetyNumber);
            
            // Форматируем цифры
            const numberBlocks = VibeCryptoVerification.formatSafetyNumber(safetyNumber);

            // Сохраняем данные для использования
            currentVerificationData = {
                myUserId,
                theirUserId,
                theirUsername,
                safetyNumber,
                emojis,
                numberBlocks
            };

            // Проверяем статус верификации
            const status = VibeCryptoVerification.getVerificationStatus(myUserId, theirUserId);

            // Показываем модалку
            showVerificationModal(theirUsername, emojis, numberBlocks, safetyNumber, status.verified);

        } catch (error) {
            console.error('Error opening key verification:', error);
            showToast('Ошибка при открытии верификации');
        }
    }

    /**
     * Показывает модальное окно верификации
     */
    function showVerificationModal(username, emojis, numberBlocks, safetyNumber, isVerified) {
        const modal = document.getElementById('key-verification-modal');
        if (!modal) {
            createVerificationModal();
        }

        // Заполняем данные
        document.getElementById('verification-username').textContent = username;
        
        // Эмодзи fingerprint
        const emojiContainer = document.getElementById('emoji-fingerprint');
        emojiContainer.innerHTML = emojis.map(e => `<span class="emoji">${e}</span>`).join('');

        // Safety Number
        const numberContainer = document.getElementById('safety-number-display');
        numberContainer.innerHTML = numberBlocks.map(b => `<span class="safety-number-block">${b}</span>`).join('');

        // QR Code
        generateQRCode(safetyNumber);

        // Статус верификации
        updateVerificationStatus(isVerified);

        // Чекбокс
        document.getElementById('verify-checkbox').checked = isVerified;
        document.getElementById('btn-mark-verified').disabled = isVerified;

        // Показываем модалку
        const modalEl = document.getElementById('key-verification-modal');
        modalEl.classList.remove('hidden');
        modalEl.style.display = 'flex';
    }

    /**
     * Создаёт HTML модального окна верификации
     */
    function createVerificationModal() {
        const modalHTML = `
        <div id="key-verification-modal" class="modal hidden" onclick="KeyVerificationUI.close()">
            <div class="modal-content" onclick="event.stopPropagation()">
                <div class="modal-header">
                    <h3>Верификация ключей</h3>
                    <button class="modal-close" onclick="KeyVerificationUI.close()">✕</button>
                </div>
                
                <div class="modal-body">
                    <p class="verification-instructions">
                        Сравните эти символы с <strong id="verification-username">пользователем</strong>
                    </p>
                    
                    <!-- Emoji Fingerprint -->
                    <div class="emoji-fingerprint" id="emoji-fingerprint">
                        <!-- Эмодзи будут добавлены динамически -->
                    </div>
                    
                    <!-- Safety Number -->
                    <div class="safety-number-container">
                        <div class="safety-number-label">Safety Number</div>
                        <div class="safety-number" id="safety-number-display">
                            <!-- Цифры будут добавлены динамически -->
                        </div>
                    </div>
                    
                    <!-- QR Code -->
                    <div class="qr-code-container" id="qr-code-container">
                        <canvas id="verification-qr-canvas"></canvas>
                        <span class="qr-code-label">Отсканируйте для сравнения</span>
                    </div>
                    
                    <!-- Verification Status -->
                    <div class="verification-status" id="verification-status">
                        <span id="verification-status-icon">⚠️</span>
                        <span id="verification-status-text">Не верифицировано</span>
                    </div>
                    
                    <!-- Checkbox -->
                    <div class="verify-checkbox-container" onclick="document.getElementById('verify-checkbox').click()">
                        <input type="checkbox" id="verify-checkbox" onchange="KeyVerificationUI.onCheckboxChange(this)">
                        <label for="verify-checkbox">Я проверил(а) ключи и они совпадают</label>
                    </div>
                    
                    <!-- Button -->
                    <button class="btn-verify" id="btn-mark-verified" onclick="KeyVerificationUI.markAsVerified()" disabled>
                        ✓ Отметить как проверенные
                    </button>
                </div>
            </div>
        </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHTML);
    }

    /**
     * Генерирует QR-код
     */
    function generateQRCode(safetyNumber) {
        const canvas = document.getElementById('verification-qr-canvas');
        if (!canvas) return;

        const qrData = VibeCryptoVerification.generateQRData(
            safetyNumber,
            currentVerificationData.myUserId,
            currentVerificationData.theirUserId
        );

        // Используем библиотеку QRCode если доступна, иначе показываем fallback
        if (typeof QRCode !== 'undefined') {
            QRCode.toCanvas(canvas, qrData, {
                width: 150,
                margin: 2,
                color: {
                    dark: '#000000',
                    light: '#ffffff'
                }
            });
        } else {
            // Fallback - генерируем простой паттерн на основе safetyNumber
            const ctx = canvas.getContext('2d');
            canvas.width = 150;
            canvas.height = 150;
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, 150, 150);
            
            // Простой визуальный паттерн
            ctx.fillStyle = '#000000';
            const size = 10;
            for (let i = 0; i < 60; i++) {
                const digit = parseInt(safetyNumber[i]);
                if (digit % 2 === 0) {
                    const x = (i % 10) * size + 25;
                    const y = Math.floor(i / 10) * size + 45;
                    ctx.fillRect(x, y, size - 1, size - 1);
                }
            }
        }
    }

    /**
     * Обновляет статус верификации в UI
     */
    function updateVerificationStatus(isVerified) {
        const statusEl = document.getElementById('verification-status');
        const iconEl = document.getElementById('verification-status-icon');
        const textEl = document.getElementById('verification-status-text');

        if (isVerified) {
            statusEl.className = 'verification-status verified';
            iconEl.textContent = '✓';
            textEl.textContent = 'Ключи верифицированы';
        } else {
            statusEl.className = 'verification-status unverified';
            iconEl.textContent = '⚠️';
            textEl.textContent = 'Не верифицировано';
        }
    }

    /**
     * Обработчик изменения чекбокса
     */
    function onCheckboxChange(checkbox) {
        const btn = document.getElementById('btn-mark-verified');
        btn.disabled = !checkbox.checked;
    }

    /**
     * Отмечает ключи как проверенные
     */
    function markAsVerified() {
        if (!currentVerificationData) return;

        VibeCryptoVerification.saveVerificationStatus(
            currentVerificationData.myUserId,
            currentVerificationData.theirUserId,
            true
        );

        updateVerificationStatus(true);
        document.getElementById('btn-mark-verified').disabled = true;
        document.getElementById('verify-checkbox').disabled = true;

        showToast('Ключи отмечены как проверенные ✓');
    }

    /**
     * Закрывает модальное окно
     */
    function close() {
        const modal = document.getElementById('key-verification-modal');
        if (modal) {
            modal.classList.add('hidden');
            modal.style.display = 'none';
        }
        currentVerificationData = null;
    }

    /**
     * Получает мой identity key
     */
    async function getMyIdentityKey() {
        try {
            const response = await fetch(`${API_URL}/keys/identity/me`, {
                headers: {
                    'Authorization': `Bearer ${state.token}`
                }
            });
            if (response.ok) {
                const data = await response.json();
                return data.identity_key;
            }
        } catch (e) {
            console.error('Error getting my identity key:', e);
        }
        return null;
    }

    /**
     * Получает identity key собеседника
     */
    async function getTheirIdentityKey(userId) {
        try {
            const response = await fetch(`${API_URL}/keys/identity/${userId}`, {
                headers: {
                    'Authorization': `Bearer ${state.token}`
                }
            });
            if (response.ok) {
                const data = await response.json();
                return data.identity_key;
            }
        } catch (e) {
            console.error('Error getting their identity key:', e);
        }
        return null;
    }

    /**
     * Добавляет кнопку верификации в профиль пользователя
     */
    function addVerifyButtonToProfile() {
        const actionsDiv = document.querySelector('.user-profile-actions');
        if (!actionsDiv) return;
        
        // Проверяем что кнопка ещё не добавлена
        if (document.getElementById('profile-verify-btn')) return;

        const btn = document.createElement('button');
        btn.id = 'profile-verify-btn';
        btn.className = 'btn';
        btn.innerHTML = '🔐 Проверить ключи';
        btn.onclick = () => {
            const userId = state.currentProfileUserId;
            const username = document.getElementById('profile-name').textContent;
            openKeyVerification(userId, username);
        };

        actionsDiv.appendChild(btn);
    }

    // Public API
    return {
        open: openKeyVerification,
        close,
        markAsVerified,
        onCheckboxChange,
        addVerifyButtonToProfile,
        getCurrentData: () => currentVerificationData
    };
})();

// Экспорт для глобального использования
if (typeof window !== 'undefined') {
    window.KeyVerificationUI = KeyVerificationUI;
}
